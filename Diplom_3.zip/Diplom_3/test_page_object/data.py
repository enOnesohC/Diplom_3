class Data:
    username = "ytrewq"
    email = "qwerty1234@yandex.ru"
    password = "12341234"

    tab_class = 'input pr-6 pl-6 input_type_text input_size_default input_status_active'
    result = "Детали ингредиента"
    element_class = 'Modal_modal__P3_V5'
